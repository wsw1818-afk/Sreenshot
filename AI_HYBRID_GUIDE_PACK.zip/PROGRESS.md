# PROGRESS.md (현재 진행: 얇게 유지)

## Dashboard (선택, 권장)
- Progress: 0%
- Token/Cost 추정: 낮음
- Risk: 낮음

## Today Goal
-

## What changed
- (파일/핵심 변경 3~7줄)

## Commands & Results
- (실행 커맨드 + 결과 요약)

## Open issues
- (재현 스텝 + 에러 원문 + 환경 정보)

## Next
1)
2)
3)

---
## Archive Rule (요약)
- 완료 항목이 20개를 넘거나 파일이 5KB를 넘으면,
  완료된 내용을 `ARCHIVE_YYYY_MM.md`로 옮기고 PROGRESS는 “현재 이슈”만 남긴다.
